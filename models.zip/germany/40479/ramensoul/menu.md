# Getränke

#Essen

## Vorspeise 前餐
* Mini Veg. Frühlingsrollen 迷你小春卷 für 3,90€

* Lieblings-Roll von Ramen Soul手工春卷 für 4,90€
 _Gebratene frische handgemachte große Frühlingsrollen gefüllt mit Hackfleisch, schwarzen Pilzen & Kräuter dazu Süß-Sauer–Dip _

* Gansu Salat 甘肅沙拉 für 4,90€
 _Gewürzte Chinakohl mit Gurken, Glasnudel, Möhren und gebratene Tofu. dazu Soja-Essig-Sauce, Spezial_

* Spinat-Soja-Möhren-Salat菠菜豆芽莳萝沙拉 für 5,50€
_Mit Glasnudel und Senfhonigsauce_

* Feine Hühnerbrustsalat蜜汁雞柳沙拉 für 5,90€
 _Mit Gurke und Knoblauch dazu spezielle Sauce vom Meister Yang (leicht Scharf)_

* Vegetarische Jiaozi 手工素餃子 für 5,50€
 _Frisch handgemachte Teigtasche gefüllt mit verschieden Gemüse und Glasnudeln sowie Kräuter_

* Guo Tie 鍋貼 für 5,50€
 _Gebratene frische handgemachte Teigtasche gefüllt mit schmackhaft gewürzten Hackfleisch_

* Jiaozi mit Fleisch 手工肉餃子 für 5,50€
 _Frisch handgemachte Teigtasche gefüllt mit Schweinefleisch & Schwarzen Pilzen_

* Zarte Hühnerbruststreifen 秘製雞柳炸物 für 6,90€
 _Frittierte, mit besonderem Gewürze und Süß-Sauer Sauce_

* enießen in der Changjiang 清炒河蝦仁 für 6,90€
 _Gebratene Teigblüte gefüllt mit Garnelen, Tomaten und sellerie (leicht Scharf)_

* Sommersregen über Huanghe 五彩蔬菜卷 für 6,40€
_Wrap mit Tofu, Pfefferminze, buntem Gemüse dazu Senf-honig –soße_

* Entlang des Waitan 雞肉时蔬卷 für 6,90€
 _Wrap gebratene Hühnerbrustfilet mit Saisongemüse eingerollt in Nudelteig & Erdnuss-Soße_

## Hauptgerichte
###Ramen Wok
_Zu jedem Hauptgericht servieren wir frische handgemachte Nudeln order Jasmin Reis 每道主食我们为您提供一份手工拉面或茉莉香米_

* Frische Handgemachte Nudeln 面魂特色醬拌素面 für 7,90€
 _Mit spezieller Soße vom Meister Song , Gansu Salat und gehackten Erdnüssen (leicht Scharf)_

* Heiße Platte "Vegetarisch" 時蔬鐵板 für 11,90€
 _mit Broccoli, Zuckererbsen, Paprika, Zucchini und Zwiebeln_

* Wandel in Shanghai 時蔬蓋澆面 für 10,90€
 _Gebratener Tofu mit Spinat, Broccoli, Sojasprossen, Möhren, Zucchini und Knoblauch, leicht Süß-Sauer-Scharf angemacht Serviert mit frischen handgemachten Nudeln oder Jasmin Reis_

* Lieblingsessen des Kommandant Xi 雞肉里脊蓋澆面 für 12,90€
_Gewürztes Hühnerfleische mit frischem Ingwer und Knoblauch mit verschiedenem Gemüsen (leicht Scharf) Serviert mit frischen handgemachten Nudeln oder Jasmin Reis_

* Flammende Berge 川香風味雞煲 für 13,90€
 _Feines Hühnerbrustfilet mit Zucchini, Soja, China Kohl und Porree in acht verschiedenen Gewürzen gebraten (Scharf)_


###Ramen Suppe
* Ramen mit verschiedene Gemüse 時蔬湯麵 für 9,90€
_Frische handgemachte Nudeln mit Soja, Tofu, Chinakohl, Champignon, Möhren, Broccoli, Zuckererbsen (leicht Scharf)_

* Ramen mit Hühnerfleisch 雞肉燒面 für 11,90€
_Frische Handgemachte Nudeln mit Soja, Tofu, Chinakohl, Champignon, Möhren, Broccoli, Zuckererbsen (leicht Scharf)_

### Nudelgerichte

* Schwarzbohne Paste Ramen 炸醬麵 für 10,90€
_deftiger schwarzbohnen-Soße mit gehacktem Schweinefleisch, Gurke, Pak Choi, Broccoli, Spinat und Möhren_

* Gute Laune durch Peking 鴨胸沙拉 für 11,90€
_Knusprig Entenbrust mit Gansu Salat, Soja-Essig-Soße_

* Traum in Verbotene Stadt 面魂特色豚肉拌面 für 11,90€
_mariniertem Schweinefleisch und Saison-Gemüse, dazu eine spezielle Soße mit gehackten Erdnüssen und gerösteten Zwiebeln_

##Nachtisch/Dessert
* Gebratene Banana mit honig & Eis für 4,40€
* Gebratene Sesamkugel mit Schwarz Sesam Füllung für 4,90€
* Gebratene Eiskugel mit honig für 4,90€