# Getränke

## Caffe
[Eisgedeck](#Eisgedeck)
* Espresso für 2,50€
* Kaffee für 2,50€
* Milchkaffee für 3,70€
* Cappuccino für 3,20€
* Caffe Latte für 3,70€
* Espresso Macchiato für 2,80€
* Doppelter Espresso für 3,80€
* Heiße Schokolade für 3,90€

## Alkoholfreie Getränke
* Van Nahmen Landschorle
	* Cassis 0,33l für 3,80€
	* Rhabarber 0,33l für 3,80€
	* Streuobst- Apfel 0,33l für 3,80€
* Van Nahmen Apfelsaft von Streuobstwiesen
	* 0,20l für 3,30€
*Proviant Limonaden
	* Zitrone-Ingwer 0,33l für 3,80€
	* Maracuja-Orange 0,33l für 3,80€
* Uerige Fassbrause
	* Rhabarber 0,33l für 3,80€
	* Holunder 0,33l für 3,80€
*Gerolsteiner naturell order Sprudel
	* 0,25l für 2,70€
	* 0,75l für 6,90€

##Alkohollastige Getränke
* Van Nahmen Apfel-Cidre 4% vol
	* 0,75l für 12,50€
*Spumante brut Bellebolle, Monteci Pescantina, Gardasse
	* 0,1L für 5,80€
*Nordmanns Bellini
	* 0,2l für 7,90€

## Bier
* Uerige Alt
	* 0,33l für 3,80€
* Tannenzäpfle Pilsener
	* 0,33l für 3,80€

## Kusmi Tee
[Eisgedeck](#Eisgedeck)
* Expure, grüner Matetee mit Zitronengras für 3,50€
* grüner China Ingwer und Zitrone für 3,50€
* grüner China Jasminblüten für 3,50€
* grüner Indien Darjeeling für 3,50€
* Schwarztee Sri Lanka Oeylon für 3,50€
* grüner Rooibos, Bio, Südafrika für 3,50€
*frischer Minztee  für 3,50€

#Essen

## Gemischtes Eis
_Eissorten nordmanns finest zzgl. 0,70€ per Kugel. Alle Kurse inkl. MWSt. Bedienung. Keine Kartenzahlung. Belegausgabe an der Zentralkasse._
* Kleine Portion(3 Sorten) für 4,60€
* Mittlere Portion(4 Sorten) für 5,90€
* Große Portion(5 Sorten) für 6,90€
* Portion Schlagsahne für 1,30€
* Hausgemachte Toppings für 1,30€

## Kindereis für Kinder
_Eissorten nordmanns finest zzgl. 0,70€ per Kugel. Alle Kurse inkl. MWSt. Bedienung. Keine Kartenzahlung. Belegausgabe an der Zentralkasse._
* Kleine Kinder(1 Sorte) für 1,90€
* Große Kinder(2 Sorten) für 3,50€
* Kinder-Spaghetti-Eis für 4,20€

## Eisspezialitäten
* Erdbeerbecher für 7,80€
_Frische Erdbeeren, Vanille- und Erdbeereis,hausgemachte Erdbeersauce, frische Schlagschne_

* Spaghetti-Eis für 7,20€
* Spaghetti-Eis + frische Erdbeeren für 7,80€
* Bananensplit für 7,50€
* Schokobecher für 7,50€
* NussBecher für 8,20€
 _Vanilleeis, Haselnusseis, Plemonteser Haselnüsse,hausgemachtes Topping, Schlagsahne_
* Himbeerbecher für 8,30€
 _Vanilleeis, frische Himbeeren,Schlagsahne,hausgemachtes Himbeertopping(saisonabhängig)_
* Rhabarberbecher für 7,20€
_hausgemachtes Rhabarberkompott, Vanilleeis, Schlagsahne(saisonabhängig)_
* Heidelbeerbecher für 8,50€
 _Heidelbeer-Joghurteis, Vanilleeis,frische wilde Waldheidelbeeren, Schlagsahne,hausgemachtes Heidelbeertopping(saisonabhängig,ganz kurze Saison)_
* Prosecco & Sorbet für 6,80€
 _Fruchtsorbet nach Wahl, zugeschüttet mit Prosecco brut_
* Joghurtbecher für 7,20€
 _Frischer Joghurt, Joghurteis, Fruchtdeko_
* Kirschbecher für 8,50€
 _Sauerkirschsorbet, Vanille- und Schokoladeneis, Schlagsahne, hausgemachtes Kirschtopping, frische pralle Süßkirschen(saisonabhängig)_
* Erdbeerbecher Flingern für 8,80€
 _Viel frische Erdbeeren, Pistazieneis, alter Balsamico_
* Herbstbecher für 7,90€
 _Zimt-,Mandeljoghurteis,Mirabelle- Mandelsorbet, Schlagsahne,gebrannte Mandeln, Topping:Mirabelle de Lorraine(saisonabhängig)_
* Puristenteller  für 7,20€
 _Viel frische Erdbeeren, Tonkabohneneis_
* Eiscafe für 5,40€
* Affogato für 3,90€
* Eisschokolade für 5,40€
* Mango-Lassi für 5,20€
* Milchshake für 5,20€
 _frische Milch und Dein Eis_

# Extras
## Eisgedeck
* nordmanns standard für 1,90€
* nordmanns finest für 2,60€
* Bananenbrot pur für 2,90€
* Bananenbrot mit eine Kugel Vanilleeis für 4,50€

 